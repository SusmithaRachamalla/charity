<?php
/**
 * Display hr in metabox.
 *
 * @author  Studio 164a
 * @package Charitable/Admin Views/Metaboxes
 * @since   1.2.0
 */

?>
<hr />