<?php
class Test_Charitable_Campaign_Fields extends Charitable_UnitTestCase {
	
}