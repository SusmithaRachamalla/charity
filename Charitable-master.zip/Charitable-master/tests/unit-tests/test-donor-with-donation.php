<?php

class Test_Charitable_Donor_With_Donation extends Charitable_UnitTestCase {

    public function test_donor_without_donation_id() {

    }
}