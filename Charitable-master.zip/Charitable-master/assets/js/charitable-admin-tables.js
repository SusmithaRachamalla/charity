jQuery( document ).ready(function($) {
    $('[data-trigger-modal]').leanModal({
        closeButton : ".modal-close"
    });
});
